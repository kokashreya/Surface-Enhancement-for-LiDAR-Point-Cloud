import feather

# Replace 'your_file.feather' with the path to your .feather file
file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\SAMPLE FEATHER\\FEATHER FILES\\315969837859633000.feather"

# Read the .feather file into a Pandas DataFrame
df = feather.read_dataframe(file_path)

# Get the column headings (column names)
column_headings = df.columns.tolist()

# Display the column headings
print("Fields in the .feather file :")
for column in column_headings:
    print(column)
