import scipy.io
import numpy as np  # Import numpy for dtype checking

# Replace 'your_file.mat' with the path to your .mat file
file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\FORD\\MAT FILES\\Scan1000.mat"

# Load the .mat file
mat_data = scipy.io.loadmat(file_path)

# Print the keys (variable names) in the .mat file
print("Variables in the .mat file :")
for key in mat_data.keys():
    print(key)
    if isinstance(mat_data[key], np.ndarray) and mat_data[key].size > 0 and hasattr(mat_data[key][0], 'dtype'):
        field_names = mat_data[key][0].dtype.names
        print("\n")
        if field_names:
            print("Fields in",key,":") 
            for field_name in field_names:
                print(field_name)
