import struct

def view_fields_in_bin(bin_file_path):
    try:
        with open(bin_file_path, 'rb') as bin_file:
            num_columns = 4  # Assuming 4 fields per record (adjust as needed)
            num_bytes_per_record = 4 * num_columns  # Assuming 4 bytes per float
            
            num_records = 0
            max_records_to_print = 10  # Maximum number of records to print
            
            while True:
                # Read a record
                data = bin_file.read(num_bytes_per_record)
                if not data:
                    break  # End of file
                
                num_records += 1
                
                # Unpack the data (assuming little-endian format)
                field1, field2, field3, field4 = struct.unpack('<ffff', data)
                
                # Display the fields for the first 'max_records_to_print' records
                if num_records <= max_records_to_print:
                    print(f"Record {num_records}: Field 1: {field1}, Field 2: {field2}, Field 3: {field3}, Field 4: {field4}")
            
            print(f"Total Number of Records: {num_records}")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    bin_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\KITTI\\BINARY FILES\\0000000000.bin"  # Replace with the path to your .bin file
    view_fields_in_bin(bin_file_path)
