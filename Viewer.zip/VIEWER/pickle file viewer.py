import pickle
import pandas as pd

# Replace 'your_file.pickle' with the path to your .pickle file
file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\PANDASET\\PICKLE FILES\\00.pkl"

# Open the .pickle file in binary read mode
with open(file_path, 'rb') as pickle_file:
    # Load the data from the .pickle file
    data = pickle.load(pickle_file)

# If the data is a Pandas DataFrame, you can retrieve column headings
if isinstance(data, pd.DataFrame):
    column_headings = data.columns.tolist()
    print("Fields in the .pickle file :")
    for heading in column_headings:
        print(heading)
else:
    print("The loaded data is not a Pandas DataFrame.")

# Do not print the contents of the loaded data
