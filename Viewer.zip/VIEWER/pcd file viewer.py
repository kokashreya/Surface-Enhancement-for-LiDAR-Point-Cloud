import open3d as o3d

# Load PCD file
pcd = o3d.io.read_point_cloud("C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\KITTI\\OR_RSC_0000000000.pcd")

# Create a visualization window with a black background
vis = o3d.visualization.Visualizer()
vis.create_window(window_name="Open3D", width=1800, height=1600)
vis.get_render_option().background_color = [0, 0, 0]  # Set background color to black

# Add the point cloud to the visualization
vis.add_geometry(pcd)

# Update and display the visualization
vis.update_geometry(pcd)
vis.poll_events()
vis.update_renderer()
vis.run()
vis.destroy_window()
