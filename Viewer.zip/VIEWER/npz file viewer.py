import numpy as np

# Replace 'your_file.npz' with the path to your .npz file
file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\SAMPLE NPZ\\20180810150607_lidar_frontcenter_000000083.npz"

# Load the .npz file
npz_data = np.load(file_path)

# Print the keys (variable names) in the .npz file
print("Variables in the .npz file:")
for key in npz_data.keys():
    print(key, npz_data[key].shape)

# Check if 'pcloud_points' exists in the .npz file
if 'pcloud_points' in npz_data:
    # Access and print the data in 'pcloud_points'
    pcloud_points = npz_data['pcloud_points']
    print("\nData in 'pcloud_points':")
    print(pcloud_points)
else:
    print("\nThe variable 'pcloud_points' does not exist in the .npz file.")
