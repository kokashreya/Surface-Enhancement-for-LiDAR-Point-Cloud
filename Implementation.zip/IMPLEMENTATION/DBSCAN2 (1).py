from matplotlib import pyplot as plt
import numpy as np
import open3d as o3d
from kneed import KneeLocator
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors

def dbscan_segmentation(dataset, eps, min_points):
    dbscan = DBSCAN(eps=eps, min_samples=min_points)
    labels = dbscan.fit_predict(dataset)
    return labels

def visualize_segmented_pointcloud(dataset, labels, point_size):
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(dataset)
    max_label = labels.max()
    colors = plt.get_cmap("tab20")(labels / (max_label if max_label > 0 else 1))
    colors[labels < 0] = 0
    pcd.colors = o3d.utility.Vector3dVector(colors[:, :3])

    vis = o3d.visualization.Visualizer()
    vis.create_window()
    vis.add_geometry(pcd)
    opt = vis.get_render_option()
    opt.point_size = point_size
    opt.background_color = np.asarray([0, 0, 0])
    vis.run()
    vis.destroy_window()

    return pcd  # Return the segmented point cloud

def save_point_cloud(pcd, output_path):
    o3d.io.write_point_cloud(output_path, pcd)

def readpcd(path):
    input_pcd_file = path
    pcd = o3d.io.read_point_cloud(input_pcd_file)
    dataset = np.asarray(pcd.points)
    return dataset

# Reading data
dataset = readpcd("C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\KITTI\\OR_RSC_0000000003.pcd")

# Calculating k
max_k = 20
avg_distances = []

for k in range(1, max_k + 1):
    neighbors = NearestNeighbors(n_neighbors=k)
    neighbors.fit(dataset)
    distances, _ = neighbors.kneighbors(dataset)
    avg_distances.append(np.mean(distances[:, -1]))

kneedle = KneeLocator(range(1, max_k + 1), avg_distances, curve='concave', direction='increasing')
optimal_k = kneedle.elbow 
print(f"Optimal k is {optimal_k}")

neighbors = NearestNeighbors(n_neighbors=optimal_k)
neighbors_fit = neighbors.fit(dataset)
distances, _ = neighbors_fit.kneighbors(dataset)
distances = np.sort(distances, axis=0)
distances = distances[:, -1]
kneedle_eps = KneeLocator(range(len(distances)), distances, S=100.0, curve='convex', direction='increasing')
optimal_eps = distances[kneedle_eps.elbow]
print(f"Optimal epsilon: {optimal_eps}")

print("Enter the value of min_samples from the set of values \n(6,8,10,12,14)")
min_samples = int(input())
labels = dbscan_segmentation(dataset, optimal_eps, min_samples)

# Save the segmented point cloud
segmented_pcd = visualize_segmented_pointcloud(dataset, labels, 0.05)
output_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\DBSCAN\\KITTI\\OR_RSC_DBSCAN_0000000003.pcd"  # Replace with your desired output path
save_point_cloud(segmented_pcd, output_path)
print(f"Segmented point cloud saved to: {output_path}")

print("satisfied (y/n)")
a = input()
while a == 'n':
    print("try another value")
    min_samples = int(input())

    labels = dbscan_segmentation(dataset, optimal_eps, min_samples)
    # Visualize with a different point size for clarity
    visualize_segmented_pointcloud(dataset, labels, 0.15)
    print("satisfied (y/n)")
    a = input()
