from matplotlib import pyplot as plt
import numpy as np
import open3d as o3d
from kneed import KneeLocator
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors

def dbscan_segmentation(dataset, eps, min_points):
    dbscan = DBSCAN(eps=eps, min_samples=min_points)
    labels = dbscan.fit_predict(dataset)
    return labels

def visualize_segmented_pointcloud(dataset, labels, point_size):
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(dataset)
    max_label = labels.max()
    colors = plt.get_cmap("tab20")(labels / (max_label if max_label > 0 else 1))
    colors[labels < 0] = 0
    pcd.colors = o3d.utility.Vector3dVector(colors[:, :3])

    return pcd, labels

def save_point_cloud(pcd, output_path):
    o3d.io.write_point_cloud(output_path, pcd)

def readpcd(path):
    input_pcd_file = path
    pcd = o3d.io.read_point_cloud(input_pcd_file)
    dataset = np.asarray(pcd.points)
    return pcd, dataset

def create_bounding_boxes(pcd, labels):
    boxes = []
    for label in np.unique(labels):
        if label == -1:  # Skip noise points
            continue
        cluster_indices = np.where(labels == label)[0]
        cluster_points = pcd.select_by_index(cluster_indices)
        aabb = cluster_points.get_axis_aligned_bounding_box()
        aabb.color = [1, 0, 0]  # Set red color for bounding boxes
        boxes.append(aabb)
    return boxes

def visualize_point_cloud_with_boxes(pcd, boxes):
    # Set blue color for the bounding boxes
    for box in boxes:
        box.color = [1, 1, 1]  # White color

    # Create a visualization window with black background
    vis = o3d.visualization.Visualizer()
    vis.create_window()
    vis.get_render_option().background_color = [0, 0, 0]  # Black background

    # Add point cloud and bounding boxes to the visualization
    vis.add_geometry(pcd)
    for box in boxes:
        vis.add_geometry(box)

    # Set a smaller point size for the point cloud
    vis.get_render_option().point_size = 2.5

    # Run the visualization
    vis.run()
    vis.destroy_window()

# Reading data
pcd, dataset = readpcd("C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\KITTI\\OR_RSC_0000000003.pcd")

# Calculating k
max_k = 20
avg_distances = []

for k in range(1, max_k + 1):
    neighbors = NearestNeighbors(n_neighbors=k)
    neighbors.fit(dataset)
    distances, _ = neighbors.kneighbors(dataset)
    avg_distances.append(np.mean(distances[:, -1]))

kneedle = KneeLocator(range(1, max_k + 1), avg_distances, curve='concave', direction='increasing')
optimal_k = kneedle.elbow 
print(f"Optimal k is {optimal_k}")

neighbors = NearestNeighbors(n_neighbors=optimal_k)
neighbors_fit = neighbors.fit(dataset)
distances, _ = neighbors_fit.kneighbors(dataset)
distances = np.sort(distances, axis=0)
distances = distances[:, -1]
kneedle_eps = KneeLocator(range(len(distances)), distances, S=100.0, curve='convex', direction='increasing')
optimal_eps = distances[kneedle_eps.elbow]
print(f"Optimal epsilon: {optimal_eps}")

print("Enter the value of min_samples from the set of values \n(6,8,10,12,14)")
min_samples = int(input())
labels = dbscan_segmentation(dataset, optimal_eps, min_samples)

# Visualize the segmented point cloud
segmented_pcd, labels = visualize_segmented_pointcloud(dataset, labels, 0.05)

# Create bounding boxes for each segmented object
boxes = create_bounding_boxes(segmented_pcd, labels)

# Visualize the point cloud with bounding boxes
visualize_point_cloud_with_boxes(segmented_pcd, boxes)

# Save the segmented point cloud
output_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\OBJECT DETECTION\\KITTI\\OR_RSC_OBJDEC_0000000003.pcd"
save_point_cloud(segmented_pcd, output_path)
print(f"Segmented point cloud saved to: {output_path}")
