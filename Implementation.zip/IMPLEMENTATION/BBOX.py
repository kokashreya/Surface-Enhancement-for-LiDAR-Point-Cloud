import open3d as o3d
import numpy as np

def visualize_point_cloud_with_boxes(pcd, boxes):
    # Set blue color for the bounding boxes
    for box in boxes:
        box.color = [0, 0, 1]  # Blue color

    geometries = boxes + [pcd]
    o3d.visualization.draw_geometries(geometries)

def create_axis_aligned_bounding_box(pcd):
    aabb = pcd.get_axis_aligned_bounding_box()
    return aabb

def create_bounding_box_points(aabb):
    # Extract the eight vertices of the bounding box
    vertices = np.array(aabb.get_box_points())

    # Create a point cloud for the bounding box vertices
    bounding_box_points = o3d.geometry.PointCloud()
    bounding_box_points.points = o3d.utility.Vector3dVector(vertices)
    bounding_box_points.paint_uniform_color([0, 0, 1])  # Blue color

    return bounding_box_points

def main():
    pcd_file = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\KITTI\\OR_RSC_0000000000.pcd"

    # Read the point cloud from the PCD file
    pcd = o3d.io.read_point_cloud(pcd_file)

    # Compute a single axis-aligned bounding box for the entire point cloud
    full_aabb = create_axis_aligned_bounding_box(pcd)
    full_aabb.color = [0, 0, 0]  # Set black color for the full bounding box

    # Cluster all points in the point cloud
    labels = np.array(pcd.cluster_dbscan(eps=0.4, min_points=10, print_progress=True))

    # Get unique labels (excluding noise points with label -1)
    unique_labels = np.unique(labels[labels >= 0])

    # Create axis-aligned bounding boxes for each cluster
    aabb_boxes = []
    for label in unique_labels:
        cluster_indices = np.where(labels == label)[0]
        cluster_points = pcd.select_by_index(cluster_indices)
        aabb = create_axis_aligned_bounding_box(cluster_points)
        aabb.color = [0, 0, 1]  # Set blue color for each axis-aligned bounding box
        aabb_boxes.append(aabb)

        # Create bounding box points and add them to the point cloud
        bounding_box_points = create_bounding_box_points(aabb)
        pcd += bounding_box_points

    # Visualize the point cloud and the axis-aligned bounding boxes
    visualize_point_cloud_with_boxes(pcd, [full_aabb] + aabb_boxes)

    # Save the point cloud with the bounding boxes
    output_pcd_file = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\BOUNDING BOX\\OR_RSC_BBOX_0000000000.pcd"
    o3d.io.write_point_cloud(output_pcd_file, pcd)
    print("Point cloud with bounding boxes saved to", output_pcd_file)

if __name__ == "__main__":
    main()
