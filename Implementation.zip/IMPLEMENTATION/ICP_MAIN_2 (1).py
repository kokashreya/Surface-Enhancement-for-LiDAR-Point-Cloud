import open3d as o3d
import numpy as np
import math

def merge_point_clouds_icp(source_points, target_points, max_iterations=1000, tolerance=1e-5, rotation_angle=0.0):
    # Create Open3D PointCloud objects from the input NumPy arrays
    source_cloud = o3d.geometry.PointCloud()
    source_cloud.points = o3d.utility.Vector3dVector(source_points)

    target_cloud = o3d.geometry.PointCloud()
    target_cloud.points = o3d.utility.Vector3dVector(target_points)

    # Initialize rotation matrix
    rotation_matrix = np.eye(3)
    # Apply rotation around the Z-axis based on user input
    rotation_matrix[:2, :2] = [[np.cos(rotation_angle), -np.sin(rotation_angle)],
                               [np.sin(rotation_angle), np.cos(rotation_angle)]]

    # Perform ICP registration
    icp_result = o3d.pipelines.registration.registration_icp(
        source_cloud, target_cloud, max_correspondence_distance=0.001,
        estimation_method=o3d.pipelines.registration.TransformationEstimationPointToPoint(),
        criteria=o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=max_iterations,
                                                                   relative_fitness=1e-6,
                                                                   relative_rmse=1e-6))

    # Transform the source cloud using the computed transformation matrix and user-defined rotation
    transformed_source = source_cloud.transform(icp_result.transformation).rotate(rotation_matrix)

    # Merge the transformed source cloud with the target cloud
    merged_cloud = target_cloud + transformed_source
    return merged_cloud

if __name__ == "__main__":
    # Load the PCD files and convert them to NumPy arrays
    source_pcd_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\KITTI\\OR_RSC_0000000002.pcd"
    target_pcd_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\KITTI\\OR_RSC_0000000003.pcd"

    source_cloud = o3d.io.read_point_cloud(source_pcd_file_path)
    target_cloud = o3d.io.read_point_cloud(target_pcd_file_path)

    source_points = np.asarray(source_cloud.points)
    target_points = np.asarray(target_cloud.points)

    # Allow the user to input the rotation angle
    print("The range of radians is -6.2832 to +6.2832 [-2pi to 2pi]")
    rotation_angle = float(input("Enter rotation angle in radians: "))


    # Allow the user to input the maximum number of iterations
    max_iterations = int(input("Enter the maximum number of iterations: "))

    # Merge the two point clouds using ICP with user-specified rotation and max iterations
    merged_cloud = merge_point_clouds_icp(source_points, target_points, max_iterations, rotation_angle=rotation_angle)

    # Visualize the merged point cloud
    o3d.visualization.draw_geometries([merged_cloud], window_name="Merged Point Cloud")

    # Save the output PCD file
    output_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\ICP\\KITTI\\OR_RSC_ICP_2_3.pcd"
    o3d.io.write_point_cloud(output_file_path, merged_cloud)
