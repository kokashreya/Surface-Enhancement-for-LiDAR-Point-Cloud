import open3d as o3d
import numpy as np

def load_pcd_file(filename):
    pcd = o3d.io.read_point_cloud(filename)
    return pcd

def create_bounding_box(points):
    # Find the minimum and maximum values in each dimension
    min_bound = np.min(points, axis=0)
    max_bound = np.max(points, axis=0)

    # Create a bounding box from the min and max values
    bounding_box = o3d.geometry.AxisAlignedBoundingBox(min_bound, max_bound)
    return bounding_box

def ransac_plane_removal(pcd, distance_threshold):
    # Plane segmentation using RANSAC
    plane_model, inliers = pcd.segment_plane(distance_threshold=distance_threshold, ransac_n=3, num_iterations=7000)
    pcd_without_ground = pcd.select_by_index(inliers, invert=True)

    # Get the ground points using the indices
    pcd_ground = pcd.select_by_index(inliers)

    return pcd_without_ground, pcd_ground

if __name__ == "__main__":
    # Replace 'input.pcd' with the path to your PCD file
    input_file ="C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\OUTLIER REMOVAL\\KITTI\\OR_0000000003.pcd"

    # Load PCD file
    pcd = load_pcd_file(input_file)

    # Get the distance threshold from the user
    print("The value of distance threshold should be in the range of 0.1 and 0.5\n")
    print("0.1 removes less ground points whereas 0.5 removes the most ground points\n")
    print("Distance threshold value can vary for different datasets\n")
    print("Most optimal value is around 0.2\n")
    distance_threshold = float(input("Enter the Distance threshold: "))

    # Create a bounding box around the point cloud
    bounding_box = create_bounding_box(np.asarray(pcd.points))

    # RANSAC plane removal with the user-defined distance threshold
    pcd_without_ground, pcd_ground = ransac_plane_removal(pcd, distance_threshold)

    # Remove ground points from the original point cloud
    pcd.points = pcd_without_ground.points

    # Save the non-ground points to a new PCD file
    output_file = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\KITTI\\OR_RSC_0000000003.pcd"
    o3d.io.write_point_cloud(output_file, pcd)

    # Visualize the non-ground points and the bounding box
    o3d.visualization.draw_geometries([pcd, bounding_box])
