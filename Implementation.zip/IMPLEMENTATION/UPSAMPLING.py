import numpy as np
import open3d as o3d

def load_pcd_file(file_path):
    # Use open3d to read the PCD file and return a point cloud object
    return o3d.io.read_point_cloud(file_path)

def max_radius_and_num_points(pcd_file):
    # Load the PCD file using Open3D
    pcd = o3d.io.read_point_cloud(pcd_file)

    # Get the array of points from the PCD file
    points = np.asarray(pcd.points)

    # Compute the distance of each point from the origin (0, 0, 0)
    distances = np.linalg.norm(points, axis=1)

    # Find the maximum distance (maximum radius)
    max_radius = np.max(distances)

    # Get the number of points in the PCD file
    num_points = len(points)

    return max_radius, num_points

def apply_moving_least_squares(point_cloud, search_radius):
    num_points = int(input("Enter the number of points you want to add: "))

    # Convert the point cloud to a NumPy array
    points = np.asarray(point_cloud.points)

    # Create an open3d KDTree for fast nearest neighbor search
    kdtree = o3d.geometry.KDTreeFlann(point_cloud)

    # Perform Moving Least Squares (MLS) smoothing
    smoothed_points = []
    for i in range(num_points):
        random_index = np.random.randint(0, points.shape[0])
        target_point = points[random_index]

        # Find the neighbors within the search radius (by Euclidean distance)
        [k, idx, _] = kdtree.search_knn_vector_3d(target_point, int(search_radius))

        neighbors = points[idx]

        # Calculate the weighted average of the neighbors' positions
        weighted_average = np.mean(neighbors, axis=0)

        smoothed_points.append(weighted_average)

    # Create a new point cloud object with the smoothed points
    smoothed_point_cloud = o3d.geometry.PointCloud()
    smoothed_point_cloud.points = o3d.utility.Vector3dVector(smoothed_points)

    return smoothed_point_cloud

if __name__ == "__main__":
    # Replace 'path/to/your/point_cloud.pcd' with the actual file path
    pcd_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\RANSAC\\PANDASET\\OR_RSC_03.pcd"
    # Load the PCD file
    point_cloud = load_pcd_file(pcd_file_path)

    # Compute the maximum radius and number of points from the origin
    max_radius, num_points = max_radius_and_num_points(pcd_file_path)
    print("The radius of the pcd file is:", max_radius)
    print("The number of points in the pcd file are:", num_points)

    # Perform MLS smoothing using the max_radius as the search radius
    smoothed_point_cloud = apply_moving_least_squares(point_cloud, max_radius)

    # Combine original and smoothed point clouds for visualization
    combined_point_cloud = point_cloud + smoothed_point_cloud

    # Save the combined point cloud to an output PCD file
    output_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\UPSAMPLING\\PANDASET\\OR_RSC_UP_03.pcd"
    o3d.io.write_point_cloud(output_file_path, combined_point_cloud)

    # Visualize the combined point cloud with Open3D
    o3d.visualization.draw_geometries([combined_point_cloud])
