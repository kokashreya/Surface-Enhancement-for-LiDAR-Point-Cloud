import open3d as o3d
import numpy as np

# Load your point cloud
pcd = o3d.io.read_point_cloud("C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\KITTI\\PCD FILES\\0000000003.pcd")

# Define the reference point
reference_point = np.array([0.0, 0.0, 0.0])

# Calculate distances from the reference point
distances = np.linalg.norm(np.asarray(pcd.points) - reference_point, axis=1)

# Calculate the mean and standard deviation of distances
mean_distance = np.mean(distances)
std_distance = np.std(distances)

# Define the threshold as mean + 2 * standard deviation
threshold = mean_distance + 2.0 * std_distance

# Identify and remove outliers based on the threshold
outlier_indices = np.where(distances > threshold)
pcd = pcd.select_by_index(np.where(distances <= threshold)[0])

# Set the background color to black
visualizer = o3d.visualization.Visualizer()
visualizer.create_window(window_name="Point Cloud Viewer", width=1800, height=1600)
visualizer.get_render_option().background_color = [0, 0, 0]

# Add the point cloud to the visualization
visualizer.add_geometry(pcd)

# Update and display the visualization
visualizer.update_geometry(pcd)
visualizer.poll_events()
visualizer.update_renderer()

# Save the output PCD file
o3d.io.write_point_cloud("C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\CODES\\IMPLEMENTATION\\OUTLIER REMOVAL\\KITTI\\OR_0000000003.pcd", pcd)

# Keep the Open3D window open until you close it manually
visualizer.run()
