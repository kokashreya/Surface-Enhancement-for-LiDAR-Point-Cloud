import os
import pyarrow.feather as feather
import open3d as o3d

# Input and output folder paths
input_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\AGROVERSE\\FEATHER FILES"  # Replace with the folder containing Feather files
output_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\AGROVERSE\\PCD FILES"  # Replace with the folder to save the PCD files

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# List all Feather files in the input folder
feather_files = [file for file in os.listdir(input_folder) if file.endswith('.feather')]

# Loop through each Feather file and convert to PCD
for feather_file in feather_files:
    feather_file_path = os.path.join(input_folder, feather_file)
    
    # Load data from Feather file
    feather_table = feather.read_feather(feather_file_path)
    data = feather_table
    
    # Assuming your data columns are named 'x', 'y', and 'z'
    point_cloud = o3d.geometry.PointCloud()
    point_cloud.points = o3d.utility.Vector3dVector(data[['x', 'y', 'z']].values)

    # Save point cloud to PCD file in the output folder
    pcd_file_name = os.path.splitext(feather_file)[0] + '.pcd'
    pcd_file_path = os.path.join(output_folder, pcd_file_name)
    o3d.io.write_point_cloud(pcd_file_path, point_cloud)

print("Conversion of Feather files to PCD complete.")
