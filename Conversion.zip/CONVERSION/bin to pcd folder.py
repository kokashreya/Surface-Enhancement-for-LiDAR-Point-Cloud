import os
import numpy as np
import open3d as o3d

# Input and output folder paths
input_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\KITTI\\BINARY FILES"  # Replace with the folder containing binary files
output_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\KITTI\\PCD FILES"  # Replace with the folder to save the PCD files

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# List all binary files in the input folder
binary_files = [file for file in os.listdir(input_folder) if file.endswith('.bin')]

# Loop through each binary file and convert to PCD
for bin_file in binary_files:
    bin_file_path = os.path.join(input_folder, bin_file)

    # Load binary data into a numpy array
    points = np.fromfile(bin_file_path, dtype=np.float32).reshape(-1, 4)

    # Create an Open3D point cloud
    point_cloud = o3d.geometry.PointCloud()
    point_cloud.points = o3d.utility.Vector3dVector(points[:, :3])  # Use only the first three columns (x, y, z)

    # Save point cloud to PCD file in the output folder
    pcd_file_name = os.path.splitext(bin_file)[0] + '.pcd'
    pcd_file_path = os.path.join(output_folder, pcd_file_name)
    o3d.io.write_point_cloud(pcd_file_path, point_cloud)

print("Conversion of binary files to PCD complete.")
