import numpy as np
import scipy.io
import open3d as o3d

# Function to convert a single .mat file to a PCD file
def mat_to_pcd(input_file, output_file):
    # Load the ".mat" file
    data = scipy.io.loadmat(input_file)

    # Access the 'XYZ' field
    xyz_data = data['SCAN']['XYZ']

    # Extract X, Y, and Z coordinates from the array
    xyz_array = xyz_data[0, 0]  # Access the first element of the array
    x = xyz_array[0]
    y = xyz_array[1]
    z = xyz_array[2]

    # Create an Open3D PointCloud object from the extracted coordinates
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(np.column_stack((x, y, z)))

    # Save the PointCloud object as a PCD file
    o3d.io.write_point_cloud(output_file, pcd)

# Input .mat file and output .pcd file paths
input_file = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\FORD\\MAT FILES\\Scan1003.mat"
output_file = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\FORD\\PCD FILES\\Scan1003.pcd"  # Replace with the path for the output PCD file

# Call the function to convert the single .mat file to a PCD file
mat_to_pcd(input_file, output_file)

print("Conversion Complete")