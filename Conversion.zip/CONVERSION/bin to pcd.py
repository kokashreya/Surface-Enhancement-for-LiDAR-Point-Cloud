import numpy as np
import open3d as o3d

# Load binary data
bin_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\KITTI\\BINARY FILES\\0000000003.bin"

# Load binary data into a numpy array
points = np.fromfile(bin_file_path, dtype=np.float32).reshape(-1, 4)

# Create an Open3D point cloud
point_cloud = o3d.geometry.PointCloud()
point_cloud.points = o3d.utility.Vector3dVector(points[:, :3])  # Use only the first three columns (x, y, z)

# Save point cloud to PCD file
pcd_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\KITTI\\PCD FILES\\0000000003.pcd"
o3d.io.write_point_cloud(pcd_file_path, point_cloud)

print("Conversion to PCD complete.")
