import pyarrow.feather as feather
import open3d as o3d

# Load data from Feather file
feather_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\AGROVERSE\\FEATHER FILES\\315969838359955000.feather"
feather_table = feather.read_feather(feather_file_path)
data = feather_table

# Assuming your data columns are named 'x', 'y', and 'z'
point_cloud = o3d.geometry.PointCloud()
point_cloud.points = o3d.utility.Vector3dVector(data[['x', 'y', 'z']].values)

# Save point cloud to PCD file
pcd_file_path = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\AGROVERSE\\PCD FILES\\315969838359955000.pcd"
o3d.io.write_point_cloud(pcd_file_path, point_cloud)

print("Conversion complete.")
