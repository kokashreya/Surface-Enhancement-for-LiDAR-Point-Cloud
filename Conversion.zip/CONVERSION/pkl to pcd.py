import open3d as o3d
import pandas as pd
import pickle
import numpy as np

def load_pkl_file(filename):
    with open(filename, 'rb') as f:
        return pickle.load(f)

def visualize_point_cloud(point_cloud):
    # Extract x, y, and z coordinates from DataFrame
    x = point_cloud['x'].values
    y = point_cloud['y'].values
    z = point_cloud['z'].values

    # Create an Open3D point cloud object
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(np.column_stack((x, y, z)))

    # Save the point cloud as a PCD file
    pcd_filename = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\PANDASET\\PCD FILES\\03.pcd"
    o3d.io.write_point_cloud(pcd_filename, pcd)

if __name__ == "__main__":
    pkl_file = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\PANDASET\\PICKLE FILES\\03.pkl"
    point_cloud_data = load_pkl_file(pkl_file)
    visualize_point_cloud(point_cloud_data)

print("Conversion Complete")