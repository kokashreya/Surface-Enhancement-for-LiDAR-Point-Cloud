import numpy as np
import open3d as o3d

# Load data from .npz file
npz_file_path = "C:\\Users\\ADMIN\\Desktop\\INTERNSHIP 2\\LiDAR\\DATASETS\\A2D2\\Npz\\20180810150607_lidar_frontcenter_000000087.npz"
data = np.load(npz_file_path)

# Access the point cloud data using the correct key
points = data['pcloud_points']

# Create a PointCloud object
point_cloud = o3d.geometry.PointCloud()
point_cloud.points = o3d.utility.Vector3dVector(points)

# Save point cloud to PCD file
pcd_file_path = "C:\\Users\\ADMIN\\Desktop\\INTERNSHIP 2\\LiDAR\\DATASETS\\A2D2\\Pcd\\20180810150607_lidar_frontcenter_000000087.pcd"
o3d.io.write_point_cloud(pcd_file_path, point_cloud)

print("Conversion complete.")
