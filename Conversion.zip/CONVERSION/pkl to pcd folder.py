import os
import open3d as o3d
import pickle
import numpy as np

def load_pkl_file(filename):
    with open(filename, 'rb') as f:
        return pickle.load(f)

def visualize_point_cloud(point_cloud, output_folder):
    # Extract x, y, and z coordinates from DataFrame
    x = point_cloud['x'].values
    y = point_cloud['y'].values
    z = point_cloud['z'].values

    # Create an Open3D point cloud object
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(np.column_stack((x, y, z)))

    # Save the point cloud as a PCD file in the output folder
    pcd_filename = os.path.join(output_folder, os.path.splitext(os.path.basename(pkl_file))[0] + '.pcd')
    o3d.io.write_point_cloud(pcd_filename, pcd)

if __name__ == "__main__":
    input_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\PANDASET\\PICKLE FILES"  # Replace with the folder containing pickle files
    output_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\PANDASET\\PCD FILES"  # Replace with the folder to save the PCD files

    # Ensure the output folder exists
    os.makedirs(output_folder, exist_ok=True)

    # List all pickle files in the input folder
    pickle_files = [file for file in os.listdir(input_folder) if file.endswith('.pkl')]

    # Loop through each pickle file, load it, and convert to PCD
    for pickle_file in pickle_files:
        pkl_file = os.path.join(input_folder, pickle_file)
        point_cloud_data = load_pkl_file(pkl_file)
        visualize_point_cloud(point_cloud_data, output_folder)

    print("Conversion of pickle files to PCD complete.")
