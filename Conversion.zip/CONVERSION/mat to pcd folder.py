import os
import numpy as np
import scipy.io
import open3d as o3d

# Function to convert .mat files to PCD files
def mat_to_pcd(input_folder, output_folder):
    # Get a list of all ".mat" files in the input folder
    mat_files = [file for file in os.listdir(input_folder) if file.endswith('.mat')]

    # Loop through each ".mat" file and convert to PCD
    for mat_file in mat_files:
        # Load the ".mat" file
        mat_path = os.path.join(input_folder, mat_file)
        data = scipy.io.loadmat(mat_path)

        # Access the 'XYZ' field
        xyz_data = data['SCAN']['XYZ']

        # Extract X, Y, and Z coordinates from the array
        xyz_array = xyz_data[0, 0]  # Access the first element of the array
        x = xyz_array[0]
        y = xyz_array[1]
        z = xyz_array[2]

        # Create an Open3D PointCloud object from the extracted coordinates
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(np.column_stack((x, y, z)))

        # Save the PointCloud object as a PCD file in the output folder
        pcd_filename = os.path.splitext(mat_file)[0] + '.pcd'
        pcd_path = os.path.join(output_folder, pcd_filename)
        o3d.io.write_point_cloud(pcd_path, pcd)

# Input and output folder paths
input_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\FORD\\MAT FILES"  # Replace with the folder containing the .mat files
output_folder = "C:\\Users\\ADMIN\\Desktop\\MAJOR PROJECT\\DATASETS\\FORD\\PCD FILES"  # Replace with the folder to save the PCD files

# Call the function to convert .mat files to PCD files
mat_to_pcd(input_folder, output_folder)

print("Conversion of .mat files to PCD complete.")
